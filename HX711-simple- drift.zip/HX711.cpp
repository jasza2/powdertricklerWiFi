#include <Arduino.h>
#include "HX711.h"
 
#if ARDUINO_VERSION <= 106
    // "yield" is not implemented as noop in older Arduino Core releases, so let's define it.
    // See also: https://stackoverflow.com/questions/34497758/what-is-the-secret-of-the-arduino-yieldfunction/34498165#34498165
    void yield(void) {};
#endif

HX711::HX711(byte dout, byte pd_sck, byte gain) {
	begin(dout, pd_sck, gain);
}

HX711::HX711() {
}

HX711::~HX711() {
}

void HX711::begin(byte dout, byte pd_sck, byte gain) {
	PD_SCK = pd_sck;
	DOUT = dout;

	pinMode(PD_SCK, OUTPUT);
	pinMode(DOUT, INPUT);

	set_gain(gain);
}

bool HX711::is_ready() {
	return digitalRead(DOUT) == LOW;
}

void HX711::set_gain(byte gain) {
	switch (gain) {
		case 128:		// channel A, gain factor 128
			GAIN = 1;
			break;
		case 64:		// channel A, gain factor 64
			GAIN = 3;
			break;
		case 32:		// channel B, gain factor 32
			GAIN = 2;
			break;
	}

	digitalWrite(PD_SCK, LOW);
	read();
}

long HX711::read() {
	// wait for the chip to become ready
	unsigned int iStart = millis();
	while (!is_ready()) {
		// Will do nothing on Arduino but prevent resets of ESP8266 (Watchdog Issue)
		yield();
		//only loop for half a second max.
		if (millis() - iStart > 500) exit;
	}

	unsigned long value = 0;
	uint8_t data[3] = { 0 };
	uint8_t filler = 0x00;

	// pulse the clock pin 24 times to read the data
	data[2] = shiftIn(DOUT, PD_SCK, MSBFIRST);
	data[1] = shiftIn(DOUT, PD_SCK, MSBFIRST);
	data[0] = shiftIn(DOUT, PD_SCK, MSBFIRST);

	// set the channel and the gain factor for the next reading using the clock pin
	for (unsigned int i = 0; i < GAIN; i++) {
		digitalWrite(PD_SCK, HIGH);
		digitalWrite(PD_SCK, LOW);
	}

	// Replicate the most significant bit to pad out a 32-bit signed integer
	if (data[2] & 0x80) {
		filler = 0xFF;
	} else {
		filler = 0x00;
	}

	// Construct a 32-bit signed integer
	value = ( static_cast<unsigned long>(filler) << 24
			| static_cast<unsigned long>(data[2]) << 16
			| static_cast<unsigned long>(data[1]) << 8
			| static_cast<unsigned long>(data[0]) );

	return static_cast<long>(value);
}

long HX711::read_average(byte times) {	
	long sum = 0;
	for (byte i = 0; i < times; i++) {
		long iresult = read();
		sum += iresult; // total for average calc	
		yield();
	}
	return sum / times;
}


float HX711::CalcMedian(float RawReading)
{
	float iresult;
	//put the value in the array
	MedianBuffer[iMedianPosition] = RawReading;
//	Serial.println(RawReading);
	iMedianPosition += 1;
	if (iMedianPosition >= SAMPLE_SIZE) iMedianPosition = 0; //dont want buffer overruns

	   // sort the array using a bubble sort:	
	float analogValues[SAMPLE_SIZE];
	//copy to a new array
	for (int i = 0; i < iMedianPosition; ++i)
	{
		analogValues[i] = MedianBuffer[i];
	}

	int out, in, swapper;
	for (out = 0; out < iMedianPosition; out++) {  // outer loop
		for (in = out; in < (iMedianPosition - 1); in++) {  // inner loop
			if (analogValues[in] > analogValues[in + 1]) {   // out of order?
			  // swap them:
				swapper = analogValues[in];
				analogValues[in] = analogValues[in + 1];
				analogValues[in + 1] = swapper;
			}
		}
	}

	// get the middle element:
	iresult = analogValues[iMedianPosition / 2];

	// print the results:
	/*	Serial.print("Array: [");
		for (int j = 0; j < iMedianPosition; j++) {
			Serial.print(analogValues[j], 3);
			Serial.print(", ");
		}
		Serial.print("]\r\n");
		Serial.print("\tMedian = ");
		Serial.print(iresult, 3);
		Serial.print("\r\n");
*/
	return iresult;

}

float HX711::read_median(byte times) {
	iMedianPosition = 0;
	float imedresult  = 0;
	for (byte i = 0; i < times; i++) {
		float iresult = read();
		imedresult = CalcMedian(iresult);
		yield();
	}
	return imedresult;
}

double HX711::get_value(byte times) {
	return read_average(times) - OFFSET;
}

float HX711::get_units(byte times) {
	return get_value(times) / SCALE;
}

void HX711::tare(byte times) {
	double sum = read_average(times);
	set_offset(sum);
}

void HX711::set_scale(float scale) {
	SCALE = scale;
}

float HX711::get_scale() {
	return SCALE;
}

void HX711::set_offset(long offset) {
	OFFSET = offset;
}

long HX711::get_offset() {
	return OFFSET;
}

void HX711::power_down() {
	digitalWrite(PD_SCK, LOW);
	digitalWrite(PD_SCK, HIGH);
}

void HX711::power_up() {
	digitalWrite(PD_SCK, LOW);
}
